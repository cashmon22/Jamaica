notify pgrst, 'reload schema';
